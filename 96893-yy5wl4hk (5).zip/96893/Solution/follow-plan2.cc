#include <iostream>
#include <fstream>
#include <libplayerc++/playerc++.h>
using namespace PlayerCc;  
player_pose2d_t readPosition(LocalizeProxy& lp);
void printRobotData(BumperProxy& bp, player_pose2d_t pose);
void printLaserData(LaserProxy& sp);
int  readPlanLength(void);
void readPlan(double *, int);
void printPlan(double *,int);  
void writePlan(double *, int);
struct vector
{
  double x;
  double y;
};
int main(int argc, char *argv[])
{  
  int counter = 0;
  double speed;           
  double turnrate;         
  player_pose2d_t  pose;   
  int pLength;
  double *plan;
  PlayerClient robot("localhost");  
  BumperProxy bp(&robot,0);  
  Position2dProxy pp(&robot,0);
  LocalizeProxy lp (&robot, 0);
  LaserProxy sp (&robot, 0);
  pp.SetMotorEnable(true);
  pLength = readPlanLength(); 
  plan = new double[pLength]; 
  readPlan(plan, pLength);    
  printPlan(plan,pLength);
  writePlan(plan, pLength);
  double targetx = 0;
  double targety = 0;
  double targeta = 0;
  bool targeta_reached = false;
  bool waypoint_reached = false;
  double initialy = 0;
  double initialx = 0;
  double distance = 0;
  bool finished = false;
  vector A;
  vector B;
  while(!finished)
  {    
    robot.Read();
    pose = readPosition(lp);
    printRobotData(bp, pose);
    if(counter > 2)
    {
      printLaserData(sp);
    }
    if(bp[0] || bp[1])
    {
      for(int i = 0; i < 10; i++)
      {
        turnrate = 0;
        speed = -0.7;
        pp.SetSpeed(speed, turnrate);
      }         
    }
    else 
    {
      for(int i = 0; i < pLength; i = i + 2)
      {
        waypoint_reached = false;
        targetx = plan[i];
        targety = plan[i+1];
        while(!waypoint_reached)
        {
          if(bp[0] || bp[1])
          {
            int i_f = 20;
            for(int i = 0; i < i_f/3; i++)
            {
              robot.Read();
              turnrate = 0;
              speed = -0.5;
              pp.SetSpeed(speed, turnrate);
              std::cout << "i #1" << "\n";
            }
            for(int i = 0; i < i_f; i++)
            {
              robot.Read();
              turnrate = 0.5;
              speed = 0;
              pp.SetSpeed(speed, turnrate);
              std::cout << "i #2" << "\n";
            }
            for(int i = 0; i < i_f; i++)
            {
              robot.Read();
              turnrate = -0.8;
              speed = 0.8;
              pp.SetSpeed(speed, turnrate);
              std::cout << "i #3" << "\n";
            }   
          }
          robot.Read();
          pose = readPosition(lp);
          printRobotData(bp, pose);
          initialx = pose.px;
          initialy = pose.py;        
          targeta = std::acos((A.x*B.x+A.y*B.y)/(sqrt(A.x*A.x+A.y*A.y)*sqrt(B.x*B.x+B.y*B.y)));
          distance = std::sqrt((initialx-targetx)*(initialx-targetx)+(initialy-targety)*(initialy-targety));
          targeta_reached = targeta < 0.05 ;
          A.x = std::cos(pose.pa);
          A.y = std::sin(pose.pa);
          B.x = targetx - initialx;
          B.y = targety - initialy;                   
          if(!targeta_reached)
          {    
            turnrate = A.x*B.y - B.x*A.y > 0 ? 0.25 : -0.25;
            speed = 0;
          } 
          else 
          {
            turnrate = 0;
            speed = distance > 1 ? distance / 2 : 0.7;        
          }
          waypoint_reached = std::abs(initialx-targetx)<0.3 && std::abs(initialy-targety)<0.3;
          std::cout << "Speed: " << speed << std::endl;      
          std::cout << "Turn rate: " << turnrate << "\n";
          std::cout << "TargetX: " << targetx << "\n";
          std::cout << "TargetY: " << targety << "\n";
          std::cout << "TargetA: " << targeta*180/3.14 << "\n\n";
          counter++;
          pp.SetSpeed(speed, turnrate);  
        } 
      }                 
    }    
    pp.SetSpeed(speed, turnrate);  
    counter++;   
    finished = true;
  }
} 
player_pose2d_t readPosition(LocalizeProxy& lp)
{
  player_localize_hypoth_t hypothesis;
  player_pose2d_t pose;
  uint32_t hCount;
  hCount = lp.GetHypothCount();
  if(hCount > 0)
  {
    hypothesis = lp.GetHypoth(0);
    pose = hypothesis.mean;
  }
  return pose;
} 
void printLaserData(LaserProxy& sp)
{
  double maxRange, minLeft, minRight, range, bearing;
  int points;
  maxRange = sp.GetMaxRange();
  minLeft = sp.MinLeft();
  minRight = sp.MinRight();
  range = sp.GetRange(5);
  bearing = sp.GetBearing(5);
  points = sp.GetCount();
  return;
} 
void printRobotData(BumperProxy& bp, player_pose2d_t pose)
{
  std::cout << "Left  bumper: " << bp[0] << std::endl;
  std::cout << "Right bumper: " << bp[1] << std::endl;
  std::cout << "We are at" << std::endl;
  std::cout << "X: " << pose.px << std::endl;
  std::cout << "Y: " << pose.py << std::endl;
  std::cout << "A: " << pose.pa*180/3.14 << std::endl;
} 
int readPlanLength(void)
{
  int length;
  std::ifstream planFile;
  planFile.open("plan.txt");
  planFile >> length;
  planFile.close();
  if((length % 2) != 0)
  {
    std::cout << "The plan has mismatched x and y coordinates" << std::endl;
    exit(1);
  }
  return length;
}
void readPlan(double *plan, int length)
{
  int skip; 
  std::ifstream planFile;
  planFile.open("plan.txt");
  planFile >> skip;
  for(int i = 0; i < length; i++)
  {
    planFile >> plan[i];
  }
  planFile.close();
} 
void printPlan(double *plan , int length)
{
  std::cout << std::endl;
  std::cout << "   x     y" << std::endl;
  for(int i = 0; i < length; i++)
  {
    std::cout.width(5);
    std::cout << plan[i] << " ";
    if((i > 0) && ((i % 2) != 0))
    {
      std::cout << std::endl;
    }
  }
  std::cout << std::endl;
} 
void writePlan(double *plan , int length)
{
  std::ofstream planFile;
  planFile.open("plan-out.txt");
  planFile << length << " ";
  for(int i = 0; i < length; i++)
  {
    planFile << plan[i] << " ";
  }
  planFile.close();
} 



