#include <iostream>
#include <fstream>
#include <libplayerc++/playerc++.h>
#include <cmath>
using namespace PlayerCc;  
player_pose2d_t readPosition(LocalizeProxy& lp);
void printRobotData(BumperProxy& bp, player_pose2d_t pose);
void printLaserData(LaserProxy& sp);
double GetFrontLaserData(LaserProxy& sp);
double GetSoftLeftLaserData(LaserProxy& sp);
double GetSoftRightLaserData(LaserProxy& sp);
double GetDistance(double, double);
void avoidObject(Position2dProxy& pp,LaserProxy& sp,bool&, bool&, bool&, double&);
int  readPlanLength(void);
void readPlan(double *, int);
void printPlan(double *,int);  
void writePlan(double *, int);
int main(int argc, char *argv[])
{  
  int counter = 0;
  double speed;       
  double turnrate;        
  player_pose2d_t  pose;  
  int pLength;
  int planPos = 0;
  double *plan;
  double angleDiff;
  PlayerClient robot("localhost");  
  BumperProxy bp(&robot,0);  
  Position2dProxy pp(&robot,0);
  LocalizeProxy lp (&robot, 0);
  LaserProxy sp (&robot, 0);
  pp.SetMotorEnable(true);
  pLength = readPlanLength(); 
  plan = new double[pLength]; 
  readPlan(plan, pLength);    
  printPlan(plan,pLength);    
  writePlan(plan, pLength);  
  bool oriented = false;
  bool atCurrDest = false;
	bool blocked = false; 
  bool collided = false; 
	double laserFront, laserLeft, laserRight;
  while(true) 
  {    
    robot.Read();
    pose = readPosition(lp);
		laserLeft = GetSoftLeftLaserData(sp);
		laserRight = GetSoftRightLaserData(sp);
		laserFront = GetFrontLaserData(sp);
		if(laserFront < 2)
    {
      std::cout << "!BLOCKED!" << std::endl;
      blocked = true;
      if(laserFront < 0.2) 
      { 
        collided = true; 
      }
    } 
    else 
    {
      blocked = false; collided = false;
    }
    double destx = plan[planPos];
    double desty = plan[planPos+1];
    double m = (desty - pose.py)/(destx - pose.px);
    double ang = atan(m);
    double xdiff = fabs(destx - pose.px);
    double ydiff = fabs(desty - pose.py);  
    double distance = GetDistance(xdiff, ydiff); 
    if(bp[0] || bp[1])
    { 
    	speed = 0;
    	turnrate= 0;
      collided = true;
      pp.SetSpeed(speed, turnrate);
      std::cout << "BUMPER HIT " << std::endl;
      avoidObject(pp,sp,oriented,blocked,collided,distance);
      else 
      { 
    	  if(ang < 0) 
        { 
          ang = fabs(ang); 
        } 	
        angleDiff = fabs(ang - pose.pa);
    	  std::cout << "angle diff: " << angleDiff << std::endl;
        if(angleDiff < .01) oriented = true;
      	else
        {
      	  turnrate = 0.1;
      	  speed = 0.0;
      	}
      }   
      if(!collided && oriented == true && !bp[0] && !bp[1])
      {
        std::cout << " !!!PROCEEDING AS NORMAL!!! " << std::endl;
        speed = 0.4;
    	  turnrate = 0.0;
      }
      std::cout << "x diff: " << xdiff << " y diff: " << ydiff << std::endl;
      if((xdiff < 0.1) && (ydiff < 0.1))
      {
    	  std::cout << "At Position" << std::endl;
    	  oriented = false;
    	  planPos += 2;
      }
      std::cout << "Speed: " << speed << std::endl;      
      std::cout << "Turn rate: " << turnrate << std::endl << std::endl;
      pp.SetSpeed(speed, turnrate);  
      counter++;
    }
  } 
  player_pose2d_t readPosition(LocalizeProxy& lp)
  {
    player_localize_hypoth_t hypothesis;
    player_pose2d_t pose;
    uint32_t hCount;
    hCount = lp.GetHypothCount();
    if(hCount > 0)
    {
      hypothesis = lp.GetHypoth(0);
      pose = hypothesis.mean;
    }
    return pose;
  } 
}
void printLaserData(LaserProxy& sp)
{
  std::cout << "Laser says..." << std::endl;
  std::cout << "Maximum distance I can see: " << sp.GetMaxRange() << std::endl;
  std::cout << "Number of readings I return: " << sp.GetCount() << std::endl;
  std::cout << "Closest thing on left: " << sp.MinLeft() << std::endl;
  std::cout << "Closest thing on right: " << sp.MinRight() << std::endl;
  std::cout << "Range of a single point: " << sp.GetRange(5) << std::endl;
  std::cout << "Bearing of a single point: " << sp.GetBearing(5) << std::endl;
  return;
} 
double GetFrontLaserData(LaserProxy& sp)
{
  double front;
  front = sp.GetRange(180);
  return front
;}
double GetSoftLeftLaserData(LaserProxy& sp)
{
  double softleft;
  softleft = sp.GetRange(225); 
  return softleft;
}
double GetSoftRightLaserData(LaserProxy& sp)
{
  double sright;
  sright = sp.GetRange(135); 
  return sright;
}
double GetDistance(double x, double y)
{
  double distance;
  distance = sqrt((x*x)+(y*y));
  return distance;
}
void avoidObject(Position2dProxy& pp,LaserProxy& sp, bool& oriented, bool& blocked, bool& collided, double& distance)
{
  double speed = 0, 
  turnrate = 0,
  laserFront = GetFrontLaserData(sp),
  laserLeft = GetSoftRightLaserData(sp),
  laserRight = GetSoftRightLaserData(sp);
  if(laserLeft < 1.0 && laserRight < 1.0)
  if(blocked)
  { 
    std::cout <<"LASERFRONT<2moving backwards"<< std::endl;
    speed= -1;
    pp.SetSpeed(speed, turnrate);
    if(laserFront > 1.0) 
    {
      std::cout <<"BLOCK IS NOW FALSE" << std::endl; blocked = false; collided = false;
    }
  }
  if(!collided)
  { 
    std::cout <<"NOT BLOCKED/COLLIDED - NOW TURNING"<< std::endl;
    turnrate = -0.1;
    speed = 0;
    pp.SetSpeed(speed, turnrate);
    if(laserFront > 5) 
    { 
      std::cout <<"FRONT CLEAR. SPEEDING UP"<< std::endl; turnrate = 0; speed = 0.4; pp.SetSpeed(speed,turnrate);
    }
    std::cout << "DISTANCE! " << distance <<std::endl;
    if(distance > 13)
    {
      std::cout <<"NOW TURNING AFTER DISTANCE>13"<< std::endl;
      speed = 0; 
      turnrate = -0.1; 
      pp.SetSpeed(speed,turnrate);
      if(oriented == true)
      { 
        turnrate = 0; speed = 0.4; pp.SetSpeed(speed,turnrate); 
      }
    }
  }
}
void printRobotData(BumperProxy& bp, player_pose2d_t pose)
{
  std::cout << "Left  bumper: " << bp[0] << std::endl;
  std::cout << "Right bumper: " << bp[1] << std::endl;
  std::cout << "We are at" << std::endl;
  std::cout << "X: " << pose.px << std::endl;
  std::cout << "Y: " << pose.py << std::endl;
  std::cout << "A: " << pose.pa << std::endl;
} 
int readPlanLength(void)
{
  int length;
  std::ifstream planFile;
  planFile.open("plan.txt");
  planFile >> length;
  planFile.close();
  if((length % 2) != 0)
  {
    std::cout << "The plan has mismatched x and y coordinates" << std::endl;
    exit(1);
  }
  return length;
} 
void readPlan(double *plan, int length)
{
  int skip;
  std::ifstream planFile;
  planFile.open("plan.txt");
  planFile >> skip;
  for(int i = 0; i < length; i++)
  {
    planFile >> plan[i];
  }
  planFile.close();
} 
void printPlan(double *plan , int length)
{
  std::cout << std::endl;
  std::cout << "   x     y" << std::endl;
  for(int i = 0; i < length; i++)
  {
    std::cout.width(5);
    std::cout << plan[i] << " ";
    if((i > 0) && ((i % 2) != 0))
    {
      std::cout << std::endl;
    }
  }
  std::cout << std::endl;
} 
void writePlan(double *plan , int length)
{
  std::ofstream planFile;
  planFile.open("plan-out.txt");
  planFile << length << " ";
  for(int i = 0; i < length; i++)
  {
    planFile << plan[i] << " ";
  }
  planFile.close();
} 



